现场设备训练数据集 (Field Device Training Dataset)
====================================================

由 Niagara 风格现场设备模拟器导出，供物理 AI / 机器学习建模使用
（节能优化、控制策略、故障诊断等）。

文件
----
- dataset_wide.csv / .parquet  宽表特征矩阵：每行一个时间对齐样本，列为各 device.point 工程值
                               （末尾可含 label_* 标签列）。这是直接可用的训练矩阵。
- dataset_long.csv             长表：每行一个 (时间, 设备, 点位, 值)。
- metadata.json                列定义/单位/量程/采样/标签定义。

本次导出
--------
- 采样间隔 : 2.0s  x 降采样 1 = 有效 2.0s
- 样本行数 : 105
- 特征列数 : 113   设备: all
- 滑窗特征 : 窗口 10 个样本，每个模拟量含 __mean/__std/__diff/__slope
- 数据集划分 : train/val/test = 0.7/0.15/0.15 (73/15/17 行)，按时间顺序，分目录存放
- 标签列   :
    label_alarm          任一报警点(名称含 alarm 的 0/1 点)激活时为 1
    label_out_of_range   任一模拟量越出配置量程 [min,max] 时为 1
    label_fault__AHU-01  设备 AHU-01 任一报警激活 或 任一模拟量越限时为 1
    label_fault__CH-01   设备 CH-01 任一报警激活 或 任一模拟量越限时为 1
    label_fault__PS-01   设备 PS-01 任一报警激活 或 任一模拟量越限时为 1

快速加载（pandas）
------------------
    import pandas as pd
    df = pd.read_csv("dataset_wide.csv", parse_dates=["timestamp_iso"])
    df = df.set_index("timestamp_iso").ffill()
    # 或 Parquet:  df = pd.read_parquet("dataset_wide.parquet")
    # 示例特征列：AHU-01.supply_air_temp, AHU-01.chw_valve_position, AHU-01.temp_setpoint, AHU-01.fan_speed_cmd ...
    y = df["label_alarm"]    if "label_alarm" in df else None   # 故障诊断标签
    X = df[[c for c in df.columns if not c.startswith("label_")]]

建模提示
--------
- 节能/控制：以可写点(*_setpoint, *_cmd)为动作、其余为状态，构造状态-动作-反馈样本。
- 故障诊断：用 label_alarm / label_out_of_range 作监督标签；或基于 metadata 量程自定义。
- 物理约束：metadata.json 的 min/max 量程可用于物理可行性约束 / 归一化。
